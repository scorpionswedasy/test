import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:parse_server_sdk_flutter/parse_server_sdk_flutter.dart';
import '../../models/UserModel.dart';
import '../../models/LiveStreamingModel.dart';
import '../../helpers/quick_help.dart';
import '../../utils/colors.dart';
import '../streaming/live_audio_room_manager.dart';
import '../streaming/zego_sdk_manager.dart';

class RoomSettingsScreen extends StatefulWidget {
  final UserModel currentUser;
  final LiveStreamingModel liveStreaming;
  final Function(Map<String, dynamic>) onSettingsChanged;

  const RoomSettingsScreen({
    Key? key,
    required this.currentUser,
    required this.liveStreaming,
    required this.onSettingsChanged,
  }) : super(key: key);

  @override
  State<RoomSettingsScreen> createState() => _RoomSettingsScreenState();
}

class _RoomSettingsScreenState extends State<RoomSettingsScreen> with TickerProviderStateMixin {
  late int selectedSeatCount;
  late bool isPrivateRoom;
  late bool allowGifts;
  late bool autoMuteNewSpeakers;
  late bool enableNoiseReduction;
  late bool allowScreenShare;
  
  bool _isUpdating = false;
  late AnimationController _animationController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    selectedSeatCount = widget.liveStreaming.getNumberOfChairs ?? 8;
    isPrivateRoom = widget.liveStreaming.getPrivate ?? false;
    allowGifts = true; // من الإعدادات
    autoMuteNewSpeakers = false; // من الإعدادات
    enableNoiseReduction = true; // من الإعدادات
    allowScreenShare = false; // من الإعدادات
    
    _animationController = AnimationController(
      duration: Duration(milliseconds: 300),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _animationController,
      curve: Curves.easeInOut,
    ));
    
    _animationController.forward();
  }

  @override
  void dispose() {
    _animationController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black.withOpacity(0.95),
      appBar: _buildAppBar(),
      body: FadeTransition(
        opacity: _fadeAnimation,
        child: SingleChildScrollView(
          padding: EdgeInsets.all(20),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              _buildHeaderInfo(),
              SizedBox(height: 30),
              
              _buildSectionTitle("إعدادات المقاعد", Icons.event_seat),
              _buildSeatCountSection(),
              SizedBox(height: 30),
              
              _buildSectionTitle("إعدادات الخصوصية", Icons.security),
              _buildPrivacySection(),
              SizedBox(height: 30),
              
              _buildSectionTitle("إعدادات التفاعل", Icons.chat),
              _buildInteractionSection(),
              SizedBox(height: 30),
              
              _buildSectionTitle("إعدادات الصوت", Icons.volume_up),
              _buildAudioSection(),
              SizedBox(height: 30),
              
              _buildActionButtons(),
            ],
          ),
        ),
      ),
    );
  }

  PreferredSizeWidget _buildAppBar() {
    return AppBar(
      backgroundColor: Colors.transparent,
      elevation: 0,
      title: Text(
        "إعدادات الغرفة",
        style: TextStyle(
          color: Colors.white,
          fontWeight: FontWeight.bold,
          fontSize: 20,
        ),
      ),
      leading: IconButton(
        icon: Container(
          padding: EdgeInsets.all(8),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.1),
            borderRadius: BorderRadius.circular(12),
          ),
          child: Icon(Icons.arrow_back, color: Colors.white, size: 20),
        ),
        onPressed: () => Navigator.pop(context),
      ),
      actions: [
        Container(
          margin: EdgeInsets.only(right: 16),
          child: TextButton.icon(
            onPressed: _isUpdating ? null : _saveSettings,
            icon: _isUpdating 
              ? SizedBox(
                  width: 16,
                  height: 16,
                  child: CircularProgressIndicator(
                    strokeWidth: 2,
                    valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                  ),
                )
              : Icon(Icons.save, color: kPrimaryColor, size: 18),
            label: Text(
              _isUpdating ? "جاري الحفظ..." : "حفظ",
              style: TextStyle(
                color: _isUpdating ? Colors.white70 : kPrimaryColor,
                fontWeight: FontWeight.bold,
              ),
            ),
            style: TextButton.styleFrom(
              backgroundColor: _isUpdating 
                ? Colors.grey.withOpacity(0.3)
                : kPrimaryColor.withOpacity(0.2),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12),
              ),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildHeaderInfo() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [kPrimaryColor.withOpacity(0.3), kPrimaryColor.withOpacity(0.1)],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: kPrimaryColor.withOpacity(0.3)),
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: kPrimaryColor,
              borderRadius: BorderRadius.circular(12),
            ),
            child: Icon(Icons.settings, color: Colors.white, size: 24),
          ),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  "غرفة ${widget.currentUser.getFullName}",
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  "معرف الغرفة: ${widget.liveStreaming.getStreamingChannel}",
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title, IconData icon) {
    return Padding(
      padding: EdgeInsets.only(bottom: 15),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: kPrimaryColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: kPrimaryColor, size: 20),
          ),
          SizedBox(width: 12),
          Text(
            title,
            style: TextStyle(
              color: Colors.white,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSeatCountSection() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "عدد المقاعد الحالي: $selectedSeatCount",
            style: TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w600),
          ),
          SizedBox(height: 15),
          Text(
            "اختر عدد المقاعد المتاحة في الغرفة",
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          SizedBox(height: 20),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [8, 12, 16, 20, 24].map((number) {
              final isSelected = selectedSeatCount == number;
              return GestureDetector(
                onTap: () {
                  setState(() {
                    selectedSeatCount = number;
                  });
                },
                child: AnimatedContainer(
                  duration: Duration(milliseconds: 200),
                  padding: EdgeInsets.symmetric(horizontal: 20, vertical: 12),
                  decoration: BoxDecoration(
                    color: isSelected ? kPrimaryColor : Colors.transparent,
                    borderRadius: BorderRadius.circular(25),
                    border: Border.all(
                      color: isSelected ? kPrimaryColor : Colors.white.withOpacity(0.3),
                      width: 2,
                    ),
                  ),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      if (isSelected) ...[
                        Icon(Icons.check, color: Colors.white, size: 16),
                        SizedBox(width: 5),
                      ],
                      Icon(Icons.event_seat, 
                           color: isSelected ? Colors.white : Colors.white70, 
                           size: 16),
                      SizedBox(width: 5),
                      Text(
                        "$number مقعد",
                        style: TextStyle(
                          color: Colors.white,
                          fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildPrivacySection() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        children: [
          _buildSwitchTile(
            icon: Icons.lock,
            title: "غرفة خاصة",
            subtitle: "تتطلب دفع رسوم للدخول",
            value: isPrivateRoom,
            onChanged: (value) {
              setState(() {
                isPrivateRoom = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildInteractionSection() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        children: [
          _buildSwitchTile(
            icon: Icons.card_giftcard,
            title: "السماح بالهدايا",
            subtitle: "يمكن للمستخدمين إرسال الهدايا",
            value: allowGifts,
            onChanged: (value) {
              setState(() {
                allowGifts = value;
              });
            },
          ),
          Divider(color: Colors.white.withOpacity(0.1), height: 30),
          _buildSwitchTile(
            icon: Icons.screen_share,
            title: "السماح بمشاركة الشاشة",
            subtitle: "يمكن للمتحدثين مشاركة شاشاتهم",
            value: allowScreenShare,
            onChanged: (value) {
              setState(() {
                allowScreenShare = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildAudioSection() {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: Colors.white.withOpacity(0.05),
        borderRadius: BorderRadius.circular(15),
        border: Border.all(color: Colors.white.withOpacity(0.1)),
      ),
      child: Column(
        children: [
          _buildSwitchTile(
            icon: Icons.mic_off,
            title: "كتم المتحدثين الجدد تلقائياً",
            subtitle: "المتحدثون الجدد يبدأون بالمايك مغلق",
            value: autoMuteNewSpeakers,
            onChanged: (value) {
              setState(() {
                autoMuteNewSpeakers = value;
              });
            },
          ),
          Divider(color: Colors.white.withOpacity(0.1), height: 30),
          _buildSwitchTile(
            icon: Icons.noise_control_off,
            title: "تقليل الضوضاء",
            subtitle: "تحسين جودة الصوت وتقليل الضوضاء",
            value: enableNoiseReduction,
            onChanged: (value) {
              setState(() {
                enableNoiseReduction = value;
              });
            },
          ),
        ],
      ),
    );
  }

  Widget _buildSwitchTile({
    required IconData icon,
    required String title,
    required String subtitle,
    required bool value,
    required Function(bool) onChanged,
  }) {
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 8),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(8),
            decoration: BoxDecoration(
              color: kPrimaryColor.withOpacity(0.2),
              borderRadius: BorderRadius.circular(8),
            ),
            child: Icon(icon, color: kPrimaryColor, size: 20),
          ),
          SizedBox(width: 15),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(
                    color: Colors.white,
                    fontSize: 16,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                SizedBox(height: 4),
                Text(
                  subtitle,
                  style: TextStyle(
                    color: Colors.white70,
                    fontSize: 12,
                  ),
                ),
              ],
            ),
          ),
          Switch(
            value: value,
            onChanged: onChanged,
            activeColor: kPrimaryColor,
            activeTrackColor: kPrimaryColor.withOpacity(0.3),
            inactiveThumbColor: Colors.white,
            inactiveTrackColor: Colors.white.withOpacity(0.3),
          ),
        ],
      ),
    );
  }

  Widget _buildActionButtons() {
    return Column(
      children: [
        // زر الحفظ الرئيسي
        Container(
          width: double.infinity,
          height: 50,
          child: ElevatedButton(
            onPressed: _isUpdating ? null : _saveSettings,
            style: ElevatedButton.styleFrom(
              backgroundColor: kPrimaryColor,
              foregroundColor: Colors.white,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
              elevation: 0,
            ),
            child: _isUpdating
                ? Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      SizedBox(
                        width: 20,
                        height: 20,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(Colors.white),
                        ),
                      ),
                      SizedBox(width: 10),
                      Text("جاري الحفظ..."),
                    ],
                  )
                : Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.save, size: 20),
                      SizedBox(width: 8),
                      Text(
                        "حفظ الإعدادات",
                        style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                      ),
                    ],
                  ),
          ),
        ),
        SizedBox(height: 15),
        
        // زر الإلغاء
        Container(
          width: double.infinity,
          height: 50,
          child: OutlinedButton(
            onPressed: _isUpdating ? null : () => Navigator.pop(context),
            style: OutlinedButton.styleFrom(
              foregroundColor: Colors.white70,
              side: BorderSide(color: Colors.white.withOpacity(0.3)),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(25),
              ),
            ),
            child: Text(
              "إلغاء",
              style: TextStyle(fontSize: 16),
            ),
          ),
        ),
      ],
    );
  }

  void _saveSettings() async {
    if (_isUpdating) return;
    
    setState(() {
      _isUpdating = true;
    });

    try {
      final settingsMap = {
        'seat_count': selectedSeatCount,
        'is_private': isPrivateRoom,
        'allow_gifts': allowGifts,
        'auto_mute_new_speakers': autoMuteNewSpeakers,
        'enable_noise_reduction': enableNoiseReduction,
        'allow_screen_share': allowScreenShare,
      };

      // حفظ الإعدادات
      await _updateSettings(settingsMap);

      if (mounted) {
        Navigator.pop(context);
        widget.onSettingsChanged(settingsMap);

        QuickHelp.showAppNotificationAdvanced(
          title: "تم الحفظ",
          message: "تم حفظ إعدادات الغرفة بنجاح",
          context: context,
          isError: false,
        );
      }
    } catch (e) {
      if (mounted) {
        QuickHelp.showAppNotificationAdvanced(
          title: "خطأ",
          message: "فشل في حفظ الإعدادات: ${e.toString()}",
          context: context,
          isError: true,
        );
      }
    } finally {
      if (mounted) {
        setState(() {
          _isUpdating = false;
        });
      }
    }
  }

  Future<void> _updateSettings(Map<String, dynamic> settings) async {
    // تحديث عدد المقاعد إذا تغير
    if (settings['seat_count'] != widget.liveStreaming.getNumberOfChairs) {
      // تحديث النموذج المحلي
      widget.liveStreaming.setNumberOfChairsDynamic = settings['seat_count'];

      // حفظ في قاعدة البيانات
      ParseResponse response = await widget.liveStreaming.save();
      if (!response.success) {
        throw Exception("فشل في حفظ البيانات في الخادم");
      }

      // تحديث مدير Zego مع معرف فريد
      final updateId = DateTime.now().millisecondsSinceEpoch.toString();
      ZegoLiveAudioRoomManager().updateSeatCount(settings['seat_count']);

      // إرسال الأمر مع معرف التحديث
      final commandMap = {
        'room_command_type': 'seat_count_changed',
        'new_seat_count': settings['seat_count'],
        'update_id': updateId,
        'sender_id': widget.currentUser.objectId,
      };

      await ZEGOSDKManager().zimService.sendRoomCommand(jsonEncode(commandMap));
    }

    // تحديث باقي الإعدادات
    widget.liveStreaming.setPrivate = settings['is_private'];
    await widget.liveStreaming.save();

    // إرسال إعدادات إضافية عبر room commands
    final settingsCommandMap = {
      'room_command_type': 'room_settings_updated',
      'settings': settings,
      'sender_id': widget.currentUser.objectId,
    };

    await ZEGOSDKManager().zimService.sendRoomCommand(jsonEncode(settingsCommandMap));
  }
}

