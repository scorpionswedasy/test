class SDKKeyCenter {
  static const int appID = 987359172;
  static const String appSign = '458f6a0c7a5202e461d4837dde4041a199f2abb4a293e640e85f3bb40d81a443';
  static const String serverSecret = 'f151ae93ef16df1a18944bdb70deba79';
}
